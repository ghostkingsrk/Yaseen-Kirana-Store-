YASEEN KIRANA STORE - ANDROID APK SOURCE (INITIAL BUILD PROJECT)

Is project se do alag Android APK banenge:
1) Customer: https://mystore2.shahrukhkhan16805.workers.dev/customer/
2) Admin:    https://mystore2.shahrukhkhan16805.workers.dev/admin/

IMPORTANT STATUS
- Yeh Android Studio/Gradle source project hai, ready APK nahi.
- Is environment mein Android SDK/Gradle installed nahi mila, isliye yahan APK compile/install test nahi hua.
- GitHub Actions workflow .github/workflows/build-apks.yml dono debug APK build karke artifacts mein upload karega.
- Debug APK testing ke liye hai. Public distribution se pehle private release signing key se signed release APK banana aur merged manifest/target SDK inspect karna zaroori hai.
- Android 14+ ke liye targetSdk 35 set hai; compileSdk 35; Java 17; AGP 8.7.3; Gradle 8.9.

SAFETY / PERMISSIONS
- INTERNET: live HTTPS store site ke liye.
- COARSE/FINE LOCATION: sirf jab website location maange; Android permission prompt aayega. Deny karne par manual address fallback website par available rehna chahiye.
- SMS, contacts, call logs, microphone, camera, background location aur all-files permission nahi hain.
- Cleartext HTTP blocked; WebView file/content access disabled; mixed content blocked.
- Play Protect ke warning-free hone ki guarantee koi source project nahi de sakta. Naye sideloaded APK par normal scan/unknown-source confirmation aa sakta hai.

BUILD
GitHub repo mein is project ke files commit karne ke baad Actions > Build Yaseen Kirana Store APKs > Run workflow.
Artifacts mein customer aur admin debug APK milenge.

SECURITY
Release APK ke liye apni private keystore file/password safe rakhein. Keystore/password GitHub repo ya ZIP mein kabhi commit na karein.

NO LIVE DATABASE CHANGES
Yeh Android wrapper project Supabase schema/data ko modify nahi karta. Existing website, PWA, products aur orders ko delete/overwrite nahi karta.


FIREBASE FCM PHASE 1 (2026-11-19)
- Firebase project: yaseen-kirana-store-2ef24 (Spark/free plan).
- Customer package: in.yaseenkirana.store.customer
- Admin package: in.yaseenkirana.store.admin
- app/google-services.json contains both registered Android app clients.
- Firebase Messaging SDK, notification channel, Android 13+ notification permission declaration, and message receiver are added.
- IMPORTANT: This is client-side FCM foundation only. It does NOT yet send or receive real store alerts end-to-end because FCM device-token registration, secure server-side FCM sender credentials, order/status event triggers, secure device-token registration to backend, server-side FCM sender credentials, order/status event triggers, and physical-device tests are still required. Android 13+ runtime notification permission prompt is included.
- Do not upload service-account private keys or FCM server credentials into this ZIP/repository. Configure secrets only in a trusted backend.


CHECKED SOURCE UPDATE (2026-11-20)
- Firebase Messaging 35.2.0 ke liye app module minSdk 24 set kiya gaya hai.
- Dono flavors (Customer/Admin) ke liye same approved Yaseen Kirana Store logo launcher icon set kiya gaya hai.
- Android 12+ native splash screen mein store green background aur logo set hai.
- Firebase config ke package names customer/admin application IDs se match karte hain.
- ZIP integrity aur required file paths verify kiye gaye. Actual APK compilation abhi GitHub Actions par hona baaki hai.

FCM ALIGNMENT PATCH (2026-11-20)
- Android FCM URL ab Supabase function `yaseen-fcm-notifications` se match karta hai.
- Android registration action ab backend ke expected `register_device` action se match karta hai.
- Native registration request configured store Origin header bhejti hai.
- Backend SQL aur function dono `store_fcm_devices` ke same columns (`installation_id`, `app_role`, `phone`, `fcm_token`, `is_active`) use karte hain.
- IMPORTANT: Website JavaScript ko YaseenNative.registerCustomerDevice(orderId, phone) ko customer order confirm ke baad, aur YaseenNative.registerAdminDevice(accessToken) ko admin login ke baad call karna hoga. Is website hook ke bina device token register nahi hoga.
- Checkout success ke baad website ko `notify_new_order` action call karna hai. Admin ke successful status/final-bill save ke baad `notify_order_update` action call karna hai. Ye event wiring is Android source ZIP mein website files ke bina add/verify nahi ki ja sakti.
- Token refresh ke liye website/app ko registration bridge dobara invoke karna chahiye; FCM `onNewToken` callback abhi automatic re-registration nahi karta.
- Supabase SQL migration aur Edge Function deploy/secrets configure hone tak real push delivery start nahi hogi.
- Actual APK build/install aur live push test abhi nahi hua. Is patch ko ready APK na samjhein.
