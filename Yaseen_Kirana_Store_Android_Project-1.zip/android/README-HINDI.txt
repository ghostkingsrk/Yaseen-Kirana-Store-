YASEEN KIRANA STORE - ANDROID APP PROJECT

App live customer page:
https://mystore2.shahrukhkhan16805.workers.dev/customer/

FREE APK BUILD STEPS (GitHub Actions):
1. GitHub repository kholo.
2. Add file > Upload files par jao.
3. Is ZIP ko phone me extract karo. ZIP ke ANDAR ke sabhi files/folders select karke repository ke root me upload karo. ZIP file ko directly upload mat karna.
4. Commit changes dabao.
5. Repository ke Actions tab me jao.
6. "Build Yaseen Kirana Store APK" workflow select karo; zarurat ho to Run workflow dabao.
7. Build complete hone par run ke neeche Artifacts me Yaseen-Kirana-Store-APK download karo.
8. Downloaded artifact ZIP extract karo. app-debug.apk install karo.

NOTE:
- APK existing live customer website ko Android WebView me kholta hai; website/database ko copy ya replace nahi karta.
- Internet required hai.
- GPS permission app me customer ki permission ke baad maangi jaati hai.
- UPI/payment links compatible installed app/browser me khulne ki koshish karte hain.
- Ye debug APK hai, manual sharing/testing ke liye. Play Store release ke liye alag signed release build aur policy steps chahiye.
- GitHub Actions free usage account ke included limits ke andar rahega; public repository workflow build is normally free for standard GitHub-hosted runners, subject to GitHub terms/limits.
