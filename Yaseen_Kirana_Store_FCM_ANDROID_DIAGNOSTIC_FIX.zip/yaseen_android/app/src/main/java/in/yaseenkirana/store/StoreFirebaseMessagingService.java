package in.yaseenkirana.store;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/** Receives Firebase Cloud Messaging messages for both product flavors. */
public class StoreFirebaseMessagingService extends FirebaseMessagingService {
    private static final String CHANNEL_ID = "yaseen_store_updates";

    @Override public void onMessageReceived(RemoteMessage message) {
        String title = message.getNotification() != null ? message.getNotification().getTitle() : null;
        String body = message.getNotification() != null ? message.getNotification().getBody() : null;
        if (title == null || title.trim().isEmpty()) title = message.getData().getOrDefault("title", "Yaseen Kirana Store");
        if (body == null || body.trim().isEmpty()) body = message.getData().getOrDefault("body", "Aapke store mein naya update hai.");
        showNotification(title, body);
    }

    @Override public void onNewToken(String token) {
        super.onNewToken(token);
        // Secure token registration to the store backend is a separate integration step.
        // Never log or expose FCM registration tokens in public logs or client-side pages.
    }

    private void showNotification(String title, String body) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Store updates", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Order and store notifications");
            manager.createNotificationChannel(channel);
        }
        Intent launch = new Intent(this, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(this, 0, launch,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).setContentIntent(pending);
        try { NotificationManagerCompat.from(this).notify((int)(System.currentTimeMillis() & 0x7fffffff), builder.build()); }
        catch (SecurityException ignored) { /* Android 13+: user may deny notification permission. */ }
    }
}
